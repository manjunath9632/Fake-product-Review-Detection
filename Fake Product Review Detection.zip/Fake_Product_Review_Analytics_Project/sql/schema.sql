CREATE TABLE reviews(
id INT PRIMARY KEY,
review_text TEXT,
rating INT,
verified_purchase BOOLEAN,
label VARCHAR(10)
);
