SELECT label, COUNT(*) AS total
FROM reviews
GROUP BY label;
