# Fake Product Review Analytics Project

Based on the uploaded presentation, this starter project contains:
- Python: ML workflow template
- SQL: Database schema and sample queries
- Power BI: Placeholder folder for .pbix
- Tableau: Placeholder folder for .twb/.twbx

Replace placeholder dataset with your own review dataset.
