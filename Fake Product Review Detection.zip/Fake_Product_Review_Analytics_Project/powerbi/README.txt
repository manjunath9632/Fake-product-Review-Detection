Place your .pbix dashboard here.
Suggested visuals: Fake vs Real, Category, Verified Purchase, Rating.