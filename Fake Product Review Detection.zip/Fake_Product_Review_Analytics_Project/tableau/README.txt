Place your Tableau workbook (.twb/.twbx) here.
Suggested dashboards mirror the Power BI visuals.